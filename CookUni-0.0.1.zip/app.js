  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyDAEw0HWT5Lv13xReV2wbmlqB5zC6Y6K7w",
    authDomain: "unicook-deeb8.firebaseapp.com",
    databaseURL: "https://unicook-deeb8-default-rtdb.firebaseio.com",
    projectId: "unicook-deeb8",
    storageBucket: "unicook-deeb8.appspot.com",
    messagingSenderId: "807620932364",
    appId: "1:807620932364:web:d767582643c4c409634f29"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);


//------------------------- Ready Data ---------------------------//
var insert, select, update, deleteButton, clear, recipeID, meal, category, categoryImageURL, description, foodImageURL, likes, prepMethod, ingredients
      function Ready() {
          const insert = document.getElementById('insert');
          const select = document.getElementById('select');
          const update = document.getElementById('update');
          const deleteButton = document.getElementById('deleteButton');
          const clear = document.getElementById('clear');
          recipeID = document.getElementById("recipeID").value;
          meal = document.getElementById("meal").value;
          category = document.getElementById("category").value;
          categoryImageURL = document.getElementById("categoryImageURL").value;
          description = document.getElementById("description").value;
          foodImageURL = document.getElementById("foodImageURL").value;
          ingredients = document.getElementById("ingredients").value;
          likes = document.getElementById("likes").value;
          prepMethod = document.getElementById("prepMethod").value;
      }
//========================= INSERT PROCESS =====================================//
document.getElementById('insert').onclick = function() {
    
    Ready();
    firebase.database().ref('recipe/'+recipeID).set({
        recipeID: recipeID,
        category: category,
        categoryImageURL: categoryImageURL,
        description: description,
        foodImageURL: foodImageURL,
        ingredients: ingredients,
        likes: likes,
        prepMethod: prepMethod,
        meal: meal
    });
}
  
// -------------------- Selection Process ---------------------------------//
document.getElementById('select').onclick = function() {
  Ready();
  firebase.database().ref('recipe/'+recipeID).on('value', function(snapshot) {
    document.getElementById('meal').value = snapshot.val().meal;
    document.getElementById('category').value = snapshot.val().category;
    document.getElementById('categoryImageURL').value = snapshot.val().categoryImageURL;
    document.getElementById('description').value = snapshot.val().description;
    document.getElementById('foodImageURL').value = snapshot.val().foodImageURL;
    document.getElementById('ingredients').value = snapshot.val().ingredients;
    document.getElementById('prepMethod').value = snapshot.val().prepMethod;
    document.getElementById('likes').value = snapshot.val().likes;
    
  })
}

//----------------------------Update Process ==================================================///

document.getElementById('update').onclick = function() {
  Ready();
  firebase.database().ref('recipe/'+recipeID).update({
      category: category,
      categoryImageURL: categoryImageURL,
      description: description,
      foodImageURL: foodImageURL,
      ingredients: ingredients,
      likes: likes,
      prepMethod: prepMethod,
      meal: meal
  })
}

//----------------------- Delete Process --------------------------------------//
document.getElementById('delete').onclick = function() {
  Ready();
  firebase.database().ref('recipe/'+recipeID).remove()
}

//------------------------ Clear Process ---------------------------------------//
// document.getElementById('clear').onclick = function() {
//   recipeID.value = '';
//   meal.value = '';
//   category.value = '';
//   categoryImageURL.value = '';
//   description.value = '';
//   foodImageURL.value = '';
//   ingredients.value = '';
//   prepMethod.value = '';
//   likes.value = '';
// }