Read This First

The data is in the data folder.

Open the index.html file first. Login as ron, password is cat.

Upon successful login, it takes you to the file /content/home.html. All 
the action takes place in the home.html and app.js files.

To do search and update, try searching for the following items:

- locomoco
- whopper
- BigMac

Search and Update only works if you search by recipeID.  Otherwise you get an alert that you must
NOT leave the recipeID blank.

You can enter new data by filing out the form and then click on the "Share It" button.
You will get an alert that says that you successfully entered data.

To verify that data is successfully entered, just remember the recipeID value that you entered and
then click on the Select button.

Data you entered is cleared upon pressing the "Share It", "Update It", and "Clear All Entries" button.

Thank you for your understanding.